import React, {useContext} from "react"
import { View, Text } from "react-native"
import { Button } from 'react-native-paper';
import { AuthContext } from "./Context";
import { PieChart } from 'react-native-gifted-charts'
import { ItemContext } from "./ItemContext";

export default function Dashboard({route}){

  const { signOut, goBack } = React.useContext(AuthContext)
  const { addItem } = React.useContext(ItemContext)

  const usuarioLogado = route.params;

  const itemPie = [{value: 5, color: '#150AD8', text: 'Comida'}, 
    {value: 1, color: '#EA7AD8', text: 'Bebida'}, 
    {value: 2, color: '#1450D8', text: 'Limpeza'}, 
    {value: 1, color: '#A07AD8', text: 'Lazer'}, 
    {value: 1, color: '#ED6665', text: 'Outro'}]


    return (
        <View>
          <PieChart data={itemPie}
          showText ={ true }
          textColor='black'
          textSize ={20}
          radius ={150}
          />

            <Button
          mode="contained" 
          buttonColor='white' 
          textColor='#054F77' 
          onPress={() => goBack()}
          style={{top:30, width:150}}>
            Voltar
            </Button>
            <Button
          mode="contained" 
          buttonColor='white' 
          textColor='#054F77' 
          onPress={() => signOut(JSON.stringify(usuarioLogado.usuarioLogado))}
          style={{top:30, width:150, buttonColor: 'red'}}>
            Apagar conta
            </Button>
        </View>
        )
}