export default itens = 
[
    {
      "name": "Farinha",
      "quantity": 2,
      "value": 10.50,
      "type": "Comida"
    },
    {
      "name": "Brownie",
      "quantity": 1,
      "value": 20.00,
      "type": "Comida"
    },
    {
      "name": "Papel Higiênico",
      "quantity": 5,
      "value": 5.75,
      "type": "Limpeza"
    },
    {
      "name": "Vassoura",
      "quantity": 3,
      "value": 15.25,
      "type": "Limpeza"
    },
    {
      "name": "Bicicleta",
      "quantity": 7,
      "value": 7.30,
      "type": "Lazer"
    },
    {
      "name": "Pão",
      "quantity": 4,
      "value": 12.99,
      "type": "Comida"
    },
    {
      "name": "Xampu",
      "quantity": 6,
      "value": 8.45,
      "type": "Comida"
    },
    {
      "name": "Doação para caridade",
      "quantity": 2,
      "value": 13.60,
      "type": "Outro"
    },
    {
      "name": "Patinho moído",
      "quantity": 1,
      "value": 25.00,
      "type": "Comida"
    },
    {
      "name": "Coca-cola",
      "quantity": 9,
      "value": 6.10,
      "type": "Bebida"
    }
  ]
